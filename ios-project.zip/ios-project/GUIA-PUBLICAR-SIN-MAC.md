# Cómo publicar tu app SIN Mac — guía paso a paso
### (Todo se hace desde el navegador de tu Chromebook)

**Idea general:** tu código se sube a GitHub, Codemagic lo compila en sus Macs
(500 minutos gratis al mes) y lo manda a tu App Store Connect. Tú solo
haces clics en páginas web. No se escribe ni una línea de código.

---

## PASO 1 — Sube el proyecto a GitHub (15 min)

1. Entra a **github.com** y crea una cuenta gratis (si no tienes).
2. Clic en **New repository** (botón verde). Ponle nombre `nosan-radio-ios`,
   déjalo en **Public**, y dale **Create repository**.
3. En tu Chromebook, descarga el archivo `ios-project.zip` que te pasé en el
   chat y **descomprímelo** (doble clic en el archivo).
4. En GitHub, dentro de tu repositorio nuevo, clic en **"uploading an existing
   file"** (o Add file → Upload files).
5. Arrastra **el CONTENIDO de la carpeta ios-project** (todos los archivos y
   carpetas que están DENTRO, incluyendo `codemagic.yaml`) a la página.
   Espera a que suban y dale **Commit changes**.

✅ Listo: tu código ya vive en GitHub.

## PASO 2 — Crea la llave de Apple (10 min)

Codemagic necesita permiso para subir la app a tu cuenta. Ese permiso es una
"API Key" que TÚ creas (nadie ve tu contraseña):

1. Entra a **appstoreconnect.apple.com** con tu cuenta (Nosan Radio LLC).
2. Arriba ve a **Users and Access** → pestaña **Integrations** →
   **App Store Connect API** → **Team Keys**.
3. Clic en **Generate API Key**, ponle nombre `Codemagic`, acceso **App Manager**,
   y dale Generate.
4. **Descarga el archivo .p8** (solo se puede descargar UNA vez, guárdalo bien).
5. Anota el **Issuer ID** (se ve arriba) y el **Key ID** (el de tu llave nueva).

✅ Listo: tienes tu llave.

## PASO 3 — Conecta Codemagic (10 min)

1. Entra a **codemagic.io** y regístrate con **Sign up with GitHub**.
2. Clic en **Add application** → elige **iOS app** → selecciona tu repositorio
   `nosan-radio-ios`.
3. Ve a **Teams** (menú de tu equipo) → **Integrations** →
   **Apple Developer Portal** → **Connect** y sube tu llave:
   Issuer ID, Key ID y el archivo .p8. Guarda.
4. Abre tu aplicación en Codemagic → **Environment variables** →
   **Add variable**: nombre `BUNDLE_ID`, valor: el Bundle ID de tu app actual.
   - ¿Cuál es? En App Store Connect → tu app **Nosan Radio** → **App Information**
     → ahí dice **Bundle ID**. Cópialo tal cual.
   - Si no lo encuentras, me dices y lo vemos juntos.

✅ Listo: todo conectado.

## PASO 4 — Compila (20-30 min de espera)

1. En Codemagic, abre tu app y dale **Start new build**.
2. Elige el workflow **"Nosan Radio a TestFlight"** y dale **Start new build**.
3. Espera. Verás el progreso en vivo. Cuando termine en verde ✅, la app ya
   está en tu App Store Connect → pestaña **TestFlight**.
4. En tu iPhone instala la app **TestFlight** (del App Store), ábrela, y ahí
   te aparecerá **Nosan Radio** para instalar y probar. 🎉

## Si algo falla

- Si el build sale en rojo ❌, abre el build → pestaña de logs → cópiame el
  error (o tómale captura) y yo lo arreglo en el código. Es normal que el
  primer intento necesite un ajuste: el código nunca se ha compilado.
- No pagas nada: el plan gratis de Codemagic da 500 minutos al mes.

## Después de probarla

Cuando la app te encante en TestFlight, el siguiente paso es enviarla a
revisión de Apple como **actualización** (versión 2.0) de tu app actual.
Me avisas y te guío en ese último paso.
