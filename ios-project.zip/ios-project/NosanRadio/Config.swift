import SwiftUI

/// Configuración central de la app Nosan Radio 98.4.
/// Cambia aquí los valores y toda la app los refleja.
enum Config {
    // MARK: - Identidad
    static let appName = "Nosan Radio"
    static let appSubtitle = "La más romántica"
    static let tagline = "La frecuencia simbólica del amor"
    static let bundleID = "com.nosanradio.lamasromantica"

    // MARK: - Stream (Live365)
    static let streamURL = URL(string: "https://streaming.live365.com/a30070")!

    // MARK: - Contacto
    static let whatsappNumber = "+1 832 277 4419"
    static let whatsappDigits = "18322774419" // sin +, ni espacios: formato wa.me
    static let whatsappBase = "https://wa.me/18322774419"
    static let website = URL(string: "https://www.poetasinfuturo.com/")!
    static let goFundMe = URL(string: "https://www.gofundme.com/f/ayudas-navidenas-2026/cl/s")!

    // MARK: - Pestañas
    /// La pestaña DUELOS queda construida pero OCULTA por ahora.
    /// Para activarla cuando Samuel lo indique: cambiar a `true`.
    static let showDuels = false

    // MARK: - Colores de marca (del diseño aprobado)
    static let gold = Color(red: 0xf2/255, green: 0xb5/255, blue: 0x44/255)      // #f2b544
    static let brandRed = Color(red: 0xe6/255, green: 0x39/255, blue: 0x46/255)  // #e63946
    static let playTop = Color(red: 0xf2/255, green: 0x54/255, blue: 0x60/255)   // #f25460
    static let playBottom = Color(red: 0xc0/255, green: 0x27/255, blue: 0x33/255)// #c02733
    static let ink = Color(red: 0xf5/255, green: 0xf2/255, blue: 0xea/255)       // #f5f2ea
    static let muted = Color(red: 0xa8/255, green: 0xb0/255, blue: 0xd0/255)     // #a8b0d0
    static let bgTop = Color(red: 0x1b/255, green: 0x24/255, blue: 0x52/255)     // #1b2452
    static let bgMid = Color(red: 0x0c/255, green: 0x11/255, blue: 0x30/255)     // #0c1130
    static let bgBottom = Color(red: 0x05/255, green: 0x07/255, blue: 0x0f/255)  // #05070f
    static let tabBar = Color(red: 0x08/255, green: 0x0b/255, blue: 0x1a/255)    // #080b1a

    /// Fondo degradado usado en todas las pantallas (igual que el prototipo).
    static var background: some View {
        LinearGradient(
            colors: [bgTop, bgMid, bgBottom],
            startPoint: .top, endPoint: .bottom
        ).ignoresSafeArea()
    }
}
