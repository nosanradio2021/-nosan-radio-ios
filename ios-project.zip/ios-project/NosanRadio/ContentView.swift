import SwiftUI

/// Barra de pestañas principal.
/// La pestaña Duelos está construida (DuelsView) pero oculta por `Config.showDuels`.
struct ContentView: View {
    @State private var selection = Tab.inicio

    enum Tab: String, Hashable {
        case inicio, duelos, dedicatorias, donar, contacto
    }

    var body: some View {
        TabView(selection: $selection) {
            HomeView()
                .tabItem { Label("Inicio", systemImage: "house.fill") }
                .tag(Tab.inicio)

            if Config.showDuels {
                DuelsView()
                    .tabItem { Label("Duelos", systemImage: "trophy.fill") }
                    .tag(Tab.duelos)
            }

            DedicatoriasView()
                .tabItem { Label("Dedicatorias", systemImage: "envelope.fill") }
                .tag(Tab.dedicatorias)

            DonateView()
                .tabItem { Label("Donar", systemImage: "heart.fill") }
                .tag(Tab.donar)

            ContactView()
                .tabItem { Label("Contacto", systemImage: "message.fill") }
                .tag(Tab.contacto)
        }
        .tint(Config.gold)
        .onAppear {
            let bar = UITabBar.appearance()
            bar.barTintColor = UIColor(Config.tabBar)
            bar.backgroundColor = UIColor(Config.tabBar)
            bar.unselectedItemTintColor = UIColor(red: 0x8b/255, green: 0x93/255, blue: 0xb8/255, alpha: 1)
        }
    }
}
