import AVFoundation
import Combine
import MediaPlayer
import UIKit

/// Reproductor del stream en vivo de Live365 con soporte de audio en segundo
/// plano, interrupciones (llamadas) y controles en pantalla de bloqueo.
final class RadioPlayer: ObservableObject {

    enum State: Equatable {
        case idle
        case loading
        case playing
        case paused
        case error(String)

        static func == (lhs: State, rhs: State) -> Bool {
            switch (lhs, rhs) {
            case (.idle, .idle), (.loading, .loading),
                 (.playing, .playing), (.paused, .paused): return true
            case (.error(let a), .error(let b)): return a == b
            default: return false
            }
        }
    }

    @Published private(set) var state: State = .idle
    @Published var volume: Float = 0.8 {
        didSet { player.volume = volume }
    }

    private let player = AVPlayer()
    private var statusObservation: NSKeyValueObservation?
    private var wasPlayingBeforeInterruption = false

    init() {
        player.volume = volume
        observeInterruptions()
        setupRemoteCommands()
        setupNowPlaying()
    }

    var isPlaying: Bool {
        if case .playing = state { return true }
        return false
    }

    func toggle() {
        isPlaying ? pause() : play()
    }

    func play() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            state = .error("No se pudo activar el audio.")
            return
        }

        state = .loading
        let item = AVPlayerItem(url: Config.streamURL)
        statusObservation?.invalidate()
        statusObservation = item.observe(\.status, options: [.new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                switch item.status {
                case .readyToPlay:
                    self?.state = .playing
                case .failed:
                    self?.state = .error("No se pudo conectar la señal. Revisa tu internet e inténtalo de nuevo.")
                case .unknown:
                    break
                @unknown default:
                    break
                }
            }
        }
        // Si el stream tarda, marcar error tras 20 s sin volverse listo
        DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in
            guard let self else { return }
            if case .loading = self.state {
                self.state = .error("La señal está tardando en responder. Toca reproducir para reintentar.")
            }
        }
        player.replaceCurrentItem(with: item)
        player.play()
    }

    func pause() {
        player.pause()
        state = .paused
        updateNowPlaying(isPlaying: false)
    }

    func retry() {
        play()
    }

    // MARK: - Interrupciones (llamadas, alarmas, Siri)

    private func observeInterruptions() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleInterruption),
            name: AVAudioSession.interruptionNotification,
            object: AVAudioSession.sharedInstance()
        )
    }

    @objc private func handleInterruption(_ note: Notification) {
        guard let info = note.userInfo,
              let typeRaw = info[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeRaw) else { return }
        switch type {
        case .began:
            wasPlayingBeforeInterruption = isPlaying
            if isPlaying { pause() }
        case .ended:
            let optsRaw = info[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            let opts = AVAudioSession.InterruptionOptions(rawValue: optsRaw)
            if wasPlayingBeforeInterruption && opts.contains(.shouldResume) {
                play()
            }
            wasPlayingBeforeInterruption = false
        @unknown default:
            break
        }
    }

    // MARK: - Pantalla de bloqueo / audífonos

    private func setupRemoteCommands() {
        let center = MPRemoteCommandCenter.shared()
        center.playCommand.addTarget { [weak self] _ in
            self?.play(); return .success
        }
        center.pauseCommand.addTarget { [weak self] _ in
            self?.pause(); return .success
        }
        center.togglePlayPauseCommand.addTarget { [weak self] _ in
            self?.toggle(); return .success
        }
    }

    private func setupNowPlaying() {
        updateNowPlaying(isPlaying: false)
    }

    private func updateNowPlaying(isPlaying: Bool) {
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: "Nosan Radio 98.4",
            MPMediaItemPropertyArtist: "La más romántica"
        ]
        if let logo = UIImage(named: "logo"),
           let art = MPMediaItemArtwork(boundsSize: logo.size, requestHandler: { _ in logo }) {
            info[MPMediaItemPropertyArtwork] = art
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}
