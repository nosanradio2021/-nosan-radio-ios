import SwiftUI

/// Pantalla de Dedicatorias — formulario que se envía directo a cabina
/// por WhatsApp (+1 832 277 4419) con el mensaje prellenado.
struct DedicatoriasView: View {
    @State private var nombre = ""
    @State private var cancion = ""
    @State private var para = ""
    @State private var mensaje = ""
    @State private var sent = false
    @FocusState private var focusedField: Field?

    enum Field { case nombre, cancion, para, mensaje }

    var body: some View {
        ZStack {
            Config.background
            ScrollView {
                VStack(spacing: 0) {
                    sectionHeader(
                        title: "Dedicatorias",
                        subtitle: "Pide tu canción y dedica con amor. Tu mensaje llega directo a cabina."
                    )

                    if sent {
                        successCard
                    } else {
                        form
                    }
                }
                .padding(.horizontal, 22)
                .padding(.top, 8)
                .padding(.bottom, 40)
            }
        }
        .onTapGesture { focusedField = nil }
    }

    // MARK: - Formulario

    private var form: some View {
        VStack(spacing: 14) {
            field(label: "Tu nombre", placeholder: "¿Cómo te llamas?", text: $nombre, field: .nombre)
            field(label: "Canción que pides", placeholder: "Título y artista", text: $cancion, field: .cancion)
            field(label: "¿Para quién es la dedicatoria?", placeholder: "Para mi esposa, para mi mamá…", text: $para, field: .para)

            VStack(alignment: .leading, spacing: 6) {
                Text("Tu mensaje (opcional)")
                    .font(.system(size: 12.5, weight: .semibold))
                    .foregroundColor(Color(red: 0xc9/255, green: 0xcf/255, blue: 0xe8/255))
                TextEditor(text: $mensaje)
                    .frame(minHeight: 88)
                    .padding(8)
                    .background(Color.white.opacity(0.07))
                    .cornerRadius(14)
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.14), lineWidth: 1))
                    .foregroundColor(Config.ink)
                    .focused($focusedField, equals: .mensaje)
            }

            Button(action: send) {
                Text("Enviar a cabina")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(16)
                    .background(LinearGradient(colors: [Config.playTop, Config.playBottom],
                                               startPoint: .topLeading, endPoint: .bottomTrailing))
                    .cornerRadius(16)
                    .shadow(color: Config.brandRed.opacity(0.4), radius: 12, x: 0, y: 6)
            }
            .buttonStyle(.plain)
            .disabled(!canSend)
            .opacity(canSend ? 1 : 0.5)
            .padding(.top, 6)

            Text("Tu dedicatoria llega a la cabina al instante por WhatsApp.")
                .font(.system(size: 12))
                .foregroundColor(Config.muted.opacity(0.85))
                .multilineTextAlignment(.center)
                .padding(12)
                .background(Color.white.opacity(0.04))
                .cornerRadius(12)
        }
    }

    private func field(label: String, placeholder: String, text: Binding<String>, field: Field) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(.system(size: 12.5, weight: .semibold))
                .foregroundColor(Color(red: 0xc9/255, green: 0xcf/255, blue: 0xe8/255))
            TextField(placeholder, text: text)
                .padding(13)
                .background(Color.white.opacity(0.07))
                .cornerRadius(14)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.14), lineWidth: 1))
                .foregroundColor(Config.ink)
                .focused($focusedField, equals: field)
                .submitLabel(.next)
        }
    }

    private var canSend: Bool {
        !nombre.trimmingCharacters(in: .whitespaces).isEmpty
            && !cancion.trimmingCharacters(in: .whitespaces).isEmpty
    }

    // MARK: - Envío por WhatsApp

    private func send() {
        var lines = ["Hola Nosan Radio, les escribo desde la app.", "",
                     "🎙 *Dedicatoria*",
                     "• Nombre: \(nombre.trimmingCharacters(in: .whitespaces))",
                     "• Canción: \(cancion.trimmingCharacters(in: .whitespaces))"]
        let paraTrim = para.trimmingCharacters(in: .whitespaces)
        if !paraTrim.isEmpty { lines.append("• Para: \(paraTrim)") }
        let msgTrim = mensaje.trimmingCharacters(in: .whitespaces)
        if !msgTrim.isEmpty { lines.append("• Mensaje: \(msgTrim)") }
        let text = lines.joined(separator: "\n")
        guard let encoded = text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "\(Config.whatsappBase)?text=\(encoded)") else { return }
        UIApplication.shared.open(url)
        withAnimation { sent = true }
    }

    // MARK: - Confirmación

    private var successCard: some View {
        VStack(spacing: 14) {
            VStack(spacing: 8) {
                Text("¡Gracias\(nombre.isEmpty ? "" : ", \(nombre)")!")
                    .font(.custom("Georgia", size: 22))
                    .foregroundColor(Config.ink)
                Text("Tu dedicatoria va en camino a cabina. Sigue escuchando Nosan Radio, la más romántica.")
                    .font(.system(size: 14))
                    .foregroundColor(Color(red: 0xc9/255, green: 0xcf/255, blue: 0xe8/255))
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
            }
            .padding(26)
            .background(Color(red: 0x1f/255, green: 0xaa/255, blue: 0x53/255).opacity(0.12))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color(red: 0x1f/255, green: 0xaa/255, blue: 0x53/255), lineWidth: 1))
            .cornerRadius(20)

            Button("Enviar otra dedicatoria") {
                nombre = ""; cancion = ""; para = ""; mensaje = ""
                withAnimation { sent = false }
            }
            .font(.system(size: 16, weight: .bold))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(16)
            .background(Color.white.opacity(0.08))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.16), lineWidth: 1))
            .cornerRadius(16)
            .buttonStyle(.plain)
        }
    }
}
