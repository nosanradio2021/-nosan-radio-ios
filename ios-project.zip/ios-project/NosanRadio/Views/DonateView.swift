import SwiftUI

/// Pantalla de Donar — tarjeta de Ayudas Navideñas con botón al GoFundMe 2026.
struct DonateView: View {
    var body: some View {
        ZStack {
            Config.background
            ScrollView {
                VStack(spacing: 0) {
                    sectionHeader(
                        title: "Ayudas Navideñas",
                        subtitle: "Cada diciembre llevamos despensas y ayuda a familias de bajos recursos."
                    )

                    VStack(spacing: 10) {
                        Text("Dona con el corazón")
                            .font(.custom("Georgia", size: 24))
                            .foregroundColor(Config.ink)
                        Text("Por más de cinco años, la familia de Nosan Radio lleva alegría a hogares en Estados Unidos, México y Honduras. Cada centavo se convierte en despensa.")
                            .font(.system(size: 14))
                            .foregroundColor(Color(red: 0xd8/255, green: 0xdc/255, blue: 0xee/255))
                            .multilineTextAlignment(.center)
                            .lineSpacing(5)
                    }
                    .padding(24)
                    .background(
                        LinearGradient(colors: [Config.gold.opacity(0.16), Config.brandRed.opacity(0.12)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .overlay(RoundedRectangle(cornerRadius: 24).stroke(Config.gold.opacity(0.4), lineWidth: 1))
                    .cornerRadius(24)

                    VStack(spacing: 10) {
                        donateItem(icon: "heart.fill",
                                   text: "100% llega a las familias. Publicamos fotos y videos de cada entrega para que veas a quién ayudaste.")
                        donateItem(icon: "clock.fill",
                                   text: "Meta 2026: llegar a más familias que nunca en Rosenberg, Richmond, Sugar Land y Houston.")
                    }
                    .padding(.top, 16)

                    Button(action: { UIApplication.shared.open(Config.goFundMe) }) {
                        Text("Donar en GoFundMe")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(Color(red: 0x3a/255, green: 0x2a/255, blue: 0x08/255))
                            .frame(maxWidth: .infinity)
                            .padding(16)
                            .background(LinearGradient(colors: [Color(red: 0xf6/255, green: 0xc6/255, blue: 0x5c/255),
                                                                Color(red: 0xd9/255, green: 0x9a/255, blue: 0x26/255)],
                                                       startPoint: .topLeading, endPoint: .bottomTrailing))
                            .cornerRadius(16)
                            .shadow(color: Config.gold.opacity(0.35), radius: 12, x: 0, y: 6)
                    }
                    .buttonStyle(.plain)
                    .padding(.top, 16)
                    .padding(.bottom, 40)
                }
                .padding(.horizontal, 22)
                .padding(.top, 8)
            }
        }
    }

    private func donateItem(icon: String, text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(Config.gold)
                .padding(.top, 2)
            Text(attributed(text))
                .font(.system(size: 13.5))
                .foregroundColor(Color(red: 0xd8/255, green: 0xdc/255, blue: 0xee/255))
                .lineSpacing(4)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Color.white.opacity(0.05))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.1), lineWidth: 1))
        .cornerRadius(16)
    }

    /// Pone en negritas el texto antes del primer punto (como en el prototipo).
    private func attributed(_ text: String) -> AttributedString {
        var a = AttributedString(text)
        if let dot = text.firstIndex(of: "."),
           let r = a.range(of: String(text[...dot])) {
            a[r].font = .system(size: 13.5, weight: .bold)
        }
        return a
    }
}
