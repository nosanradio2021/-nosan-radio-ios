import SwiftUI

/// Pantalla de Contacto — WhatsApp en cabina, número de oyentes y sitio web.
struct ContactView: View {
    var body: some View {
        ZStack {
            Config.background
            ScrollView {
                VStack(spacing: 0) {
                    sectionHeader(
                        title: "Contacto",
                        subtitle: "Escríbenos, pide tu canción o manda tu poesía."
                    )

                    VStack(spacing: 12) {
                        Button(action: openWhatsApp) {
                            Text("WhatsApp en cabina")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(16)
                                .background(Color(red: 0x1f/255, green: 0xaa/255, blue: 0x53/255))
                                .cornerRadius(16)
                                .shadow(color: Color(red: 0x1f/255, green: 0xaa/255, blue: 0x53/255).opacity(0.35),
                                        radius: 12, x: 0, y: 6)
                        }
                        .buttonStyle(.plain)

                        Text(Config.whatsappNumber)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(Config.muted)

                        Button(action: { UIApplication.shared.open(Config.website) }) {
                            Text("poetasinfuturo.com")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(16)
                                .background(Color.white.opacity(0.08))
                                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.16), lineWidth: 1))
                                .cornerRadius(16)
                        }
                        .buttonStyle(.plain)
                    }

                    Text("Noventa y ocho punto cuatro,\nla frecuencia simbólica del amor.")
                        .italic()
                        .font(.system(size: 12))
                        .foregroundColor(Config.muted.opacity(0.85))
                        .multilineTextAlignment(.center)
                        .lineSpacing(5)
                        .padding(.top, 26)
                        .padding(.bottom, 40)
                }
                .padding(.horizontal, 22)
                .padding(.top, 8)
            }
        }
    }

    private func openWhatsApp() {
        let text = "Hola Nosan Radio, les escribo desde la app"
        guard let encoded = text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "\(Config.whatsappBase)?text=\(encoded)") else { return }
        UIApplication.shared.open(url)
    }
}
