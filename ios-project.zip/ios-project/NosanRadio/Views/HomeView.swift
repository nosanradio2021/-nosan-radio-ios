import SwiftUI

/// Pantalla de Inicio — réplica del diseño aprobado en el prototipo v2:
/// marca, logo, insignia EN VIVO, botón play/pausa, ecualizador y volumen.
struct HomeView: View {
    @EnvironmentObject private var player: RadioPlayer
    @State private var pulse = false

    var body: some View {
        ZStack {
            Config.background
            ScrollView {
                VStack(spacing: 0) {
                    Text(Config.tagline.uppercased())
                        .font(.system(size: 11, weight: .medium))
                        .tracking(3)
                        .foregroundColor(Config.gold)
                        .padding(.top, 8)

                    Text("NOSAN ")
                        .font(.custom("Georgia", size: 32)).bold()
                        .foregroundColor(Config.ink)
                    + Text("RADIO")
                        .font(.custom("Georgia", size: 32)).bold()
                        .foregroundColor(Config.brandRed)
                    + Text(" 98.4")
                        .font(.custom("Georgia", size: 32)).bold()
                        .foregroundColor(Config.ink)

                    Text(Config.appSubtitle)
                        .italic()
                        .font(.system(size: 14))
                        .foregroundColor(Config.muted)
                        .padding(.top, 2)

                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 168)
                        .cornerRadius(26)
                        .shadow(color: Config.brandRed.opacity(0.28), radius: 20, x: 0, y: 8)
                        .padding(.top, 18)

                    liveBadge
                        .padding(.top, 16)

                    playerCard
                        .padding(.top, 16)

                    Text("Señal en vivo directo de tu estación en Live365.")
                        .font(.system(size: 12))
                        .foregroundColor(Config.muted.opacity(0.85))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                        .padding(.top, 18)
                        .padding(.bottom, 40)
                }
                .padding(.horizontal, 22)
            }
        }
    }

    // MARK: - Insignia EN VIVO

    private var liveBadge: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(Config.brandRed)
                .frame(width: 9, height: 9)
                .scaleEffect(pulse ? 0.8 : 1.0)
                .opacity(pulse ? 0.35 : 1.0)
                .onAppear {
                    withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) {
                        pulse = true
                    }
                }
            Text("EN VIVO")
                .font(.system(size: 12, weight: .bold))
                .tracking(2)
        }
        .foregroundColor(Color(red: 1, green: 0x8a/255, blue: 0x94/255))
        .padding(.horizontal, 16)
        .padding(.vertical, 7)
        .background(Config.brandRed.opacity(0.14))
        .overlay(
            Capsule().stroke(Config.brandRed, lineWidth: 1)
        )
        .clipShape(Capsule())
    }

    // MARK: - Tarjeta del reproductor

    private var playerCard: some View {
        VStack(spacing: 14) {
            Button(action: { player.toggle() }) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [Config.playTop, Config.playBottom],
                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 92, height: 92)
                        .shadow(color: Config.brandRed.opacity(0.45), radius: 18, x: 0, y: 8)
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 36))
                        .foregroundColor(.white)
                        .offset(x: player.isPlaying ? 0 : 3)
                }
            }
            .buttonStyle(.plain)
            .accessibilityLabel(player.isPlaying ? "Pausar" : "Reproducir")

            EqualizerView(animating: player.isPlaying)

            statusText

            HStack(spacing: 10) {
                Image(systemName: "speaker.fill")
                    .foregroundColor(Config.muted)
                Slider(value: $player.volume, in: 0...1)
                    .tint(Config.brandRed)
                    .accessibilityLabel("Volumen")
                Image(systemName: "speaker.wave.3.fill")
                    .foregroundColor(Config.muted)
            }
            .padding(.top, 4)
        }
        .padding(24)
        .background(Color.white.opacity(0.05))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.1), lineWidth: 1))
        .cornerRadius(24)
    }

    @ViewBuilder
    private var statusText: some View {
        switch player.state {
        case .idle:
            Text("Toca reproducir para escuchar en vivo")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(Config.ink)
        case .loading:
            HStack(spacing: 8) {
                ProgressView().tint(Config.gold)
                Text("Conectando la señal…")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Config.ink)
            }
        case .playing:
            VStack(spacing: 3) {
                Text("Nosan Radio 98.4")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Config.ink)
                Text("Música romántica las 24 horas")
                    .font(.system(size: 12))
                    .foregroundColor(Config.muted)
            }
        case .paused:
            Text("En pausa — toca para seguir escuchando")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(Config.ink)
        case .error(let message):
            VStack(spacing: 8) {
                Text(message)
                    .font(.system(size: 13))
                    .foregroundColor(Color(red: 1, green: 0x8a/255, blue: 0x94/255))
                    .multilineTextAlignment(.center)
                Button("Reintentar") { player.retry() }
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(Config.brandRed)
                    .cornerRadius(12)
            }
        }
    }
}

/// Barras del ecualizador animadas mientras suena (como en el prototipo).
struct EqualizerView: View {
    let animating: Bool
    @State private var heights: [CGFloat] = [8, 8, 8, 8, 8]

    var body: some View {
        HStack(alignment: .bottom, spacing: 5) {
            ForEach(0..<5, id: \.self) { i in
                RoundedRectangle(cornerRadius: 3)
                    .fill(Config.gold)
                    .frame(width: 6, height: heights[i])
            }
        }
        .frame(height: 34)
        .onChange(of: animating) { on in
            if on { animate() } else { heights = [8, 8, 8, 8, 8] }
        }
        .onAppear { if animating { animate() } }
    }

    private func animate() {
        guard animating else { return }
        withAnimation(.easeInOut(duration: 0.45)) {
            heights = (0..<5).map { _ in CGFloat.random(in: 8...30) }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { animate() }
    }
}
