import SwiftUI

/// Pantalla de Duelos — CONSTRUIDA PERO OCULTA por ahora (Config.showDuels = false).
/// Incluye el duelo de ejemplo aprobado (José José vs Juan Gabriel) con votación
/// local de demostración. En la versión final los duelos los crea Samuel desde su
/// panel y los votos se cuentan en el backend en tiempo real.
struct DuelsView: View {
    // Votos de demostración (igual que el prototipo)
    @State private var voted: String? = nil
    private let baseA = 342
    private let baseB = 298

    var body: some View {
        ZStack {
            Config.background
            ScrollView {
                VStack(spacing: 0) {
                    sectionHeader(
                        title: "Duelo musical",
                        subtitle: "Tú propones el duelo, tu gente decide quién gana."
                    )

                    VStack(spacing: 0) {
                        Text("En un duelo entre estos dos gigantes de la música romántica, ¿quién crees tú que ganaría?")
                            .font(.custom("Georgia", size: 17))
                            .multilineTextAlignment(.center)
                            .foregroundColor(Config.ink)
                            .lineSpacing(6)
                            .padding(.bottom, 18)

                        if voted == nil {
                            duelOption(artist: "José José", song: "«El Triste»") { voted = "a" }
                            Text("VS")
                                .font(.system(size: 15, weight: .black))
                                .tracking(4)
                                .foregroundColor(Config.brandRed)
                                .padding(.vertical, 10)
                            duelOption(artist: "Juan Gabriel", song: "«Querida»") { voted = "b" }
                        } else {
                            results
                        }
                    }
                    .padding(22)
                    .background(Color.white.opacity(0.05))
                    .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.1), lineWidth: 1))
                    .cornerRadius(24)

                    Text("En la app final, tú creas el duelo desde tu panel, avisas por push y los votos se cuentan en tiempo real.")
                        .font(.system(size: 12))
                        .foregroundColor(Config.muted.opacity(0.85))
                        .multilineTextAlignment(.center)
                        .padding(12)
                        .background(Color.white.opacity(0.04))
                        .cornerRadius(12)
                        .padding(.top, 16)
                        .padding(.bottom, 40)
                }
                .padding(.horizontal, 22)
                .padding(.top, 8)
            }
        }
    }

    private func duelOption(artist: String, song: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Text(artist)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundColor(Config.ink)
                Text(song)
                    .font(.system(size: 13))
                    .foregroundColor(Config.gold)
            }
            .frame(maxWidth: .infinity)
            .padding(16)
            .background(Color.white.opacity(0.07))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Config.gold.opacity(0.4), lineWidth: 1))
            .cornerRadius(16)
        }
        .buttonStyle(.plain)
    }

    private var results: some View {
        let va = baseA + (voted == "a" ? 1 : 0)
        let vb = baseB + (voted == "b" ? 1 : 0)
        let total = va + vb
        let pa = Int(round(Double(va) / Double(total) * 100))
        let pb = 100 - pa
        return VStack(spacing: 14) {
            resultRow(name: "José José", pct: pa, color: Config.brandRed)
            resultRow(name: "Juan Gabriel", pct: pb, color: Config.gold)
            Text("\(total) votos · actualizado en vivo")
                .font(.system(size: 12))
                .foregroundColor(Config.muted)
        }
    }

    private func resultRow(name: String, pct: Int, color: Color) -> some View {
        VStack(spacing: 6) {
            HStack {
                Text(name).font(.system(size: 13.5, weight: .semibold)).foregroundColor(Config.ink)
                Spacer()
                Text("\(pct)%").font(.system(size: 13.5, weight: .semibold)).foregroundColor(Config.ink)
            }
            GeometryReader { geo in
                RoundedRectangle(cornerRadius: 6)
                    .fill(color)
                    .frame(width: geo.size.width * CGFloat(pct) / 100)
                    .animation(.easeOut(duration: 0.8), value: pct)
            }
            .frame(height: 12)
            .background(Color.white.opacity(0.1))
            .cornerRadius(6)
        }
    }
}

/// Encabezado de sección reutilizable (título serif + subtítulo).
func sectionHeader(title: String, subtitle: String) -> some View {
    VStack(spacing: 6) {
        Text(title)
            .font(.custom("Georgia", size: 24))
            .foregroundColor(Config.ink)
        Text(subtitle)
            .font(.system(size: 13))
            .foregroundColor(Config.muted)
            .multilineTextAlignment(.center)
            .lineSpacing(3)
    }
    .padding(.bottom, 16)
}
