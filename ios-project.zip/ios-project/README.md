# Nosan Radio 98.4 — Proyecto Xcode (iOS)

App nativa de **Nosan Radio 98.4 — La más romántica**, lista para reemplazar la app de Live365.
Diseño aprobado por Samuel (prototipo v2, 31/10/2026).

## Lo que incluye

- **5 pestañas:** Inicio, Duelos, Dedicatorias, Donar, Contacto.
  - La pestaña **Duelos está construida pero OCULTA** (`Config.showDuels = false` en `NosanRadio/Config.swift`). Para activarla cuando Samuel lo indique, cambiar ese valor a `true` y recompilar.
- **Inicio:** réplica del diseño aprobado — marca, logo, insignia EN VIVO pulsante, botón play/pausa grande, ecualizador animado, control de volumen y estados (conectando / en vivo / error con reintento).
- **Stream en vivo:** `https://streaming.live365.com/a30070` con `AVPlayer`; audio en segundo plano (`UIBackgroundModes = audio`), controles en pantalla de bloqueo y audífonos, y manejo de interrupciones (llamadas).
- **Dedicatorias:** formulario (nombre, canción, para quién, mensaje) que abre WhatsApp directo a cabina **+1 832 277 4419** (`wa.me/18322774419`) con el mensaje prellenado.
- **Donar:** tarjeta de Ayudas Navideñas con botón al GoFundMe 2026.
- **Contacto:** botón de WhatsApp en cabina, número visible y enlace a poetasinfuturo.com.
- **Bundle ID:** `com.nosanradio.lamasromantica` · **Target:** iOS 16+ · **Stack:** SwiftUI.
- **Íconos:** `AppIcon.appiconset` completo (15 tamaños, incluido 1024) generado del logo oficial rojo. **Launch screen** con el logo sobre fondo oscuro.
- Todo el texto de la app está en español.

## ⚠️ Nota honesta

Este proyecto está **completo en código**, pero se generó en Linux: **no se puede compilar ni firmar aquí**. Para compilar, firmar y subir a App Store Connect se necesita **una Mac con Xcode 15 o superior**. Nada de este proyecto requiere cambios de código para compilar — solo firma y un par de decisiones que se listan abajo.

## Cómo abrirlo y compilarlo (en tu Mac)

1. Copia la carpeta `ios-project/` a tu Mac y abre `NosanRadio.xcodeproj` con Xcode.
2. En el panel del proyecto → pestaña **Signing & Capabilities**, marca **Automatically manage signing** y elige tu **Team** (Nosan Radio LLC). El Bundle ID ya viene como `com.nosanradio.lamasromantica`.
   - Si Xcode dice que el Bundle ID ya está en uso: es porque la app vieja lo usa. En ese caso hay dos caminos (ver "Decisiones pendientes" abajo).
3. Conecta tu iPhone o elige un simulador y presiona **▶ Run** para probarla.

## Cómo subirla a App Store Connect

1. En Xcode, menú **Product → Archive**. Espera a que termine.
2. En la ventana **Organizer**, selecciona el archive → **Distribute App** → **App Store Connect** → **Upload**.
3. Entra a [App Store Connect](https://appstoreconnect.apple.com) → tu app → **TestFlight**: el build aparece en unos minutos para probarlo en tu iPhone con la app TestFlight.
4. Cuando esté probada: en App Store Connect crea la **versión 1.0**, llena la ficha (descripción, capturas, keywords) y envía a revisión.

## Decisiones que Samuel debe tomar

1. **¿Reemplazo o app nueva?** Si la app vieja de Live365 usa el mismo Bundle ID, esta versión debe publicarse **como actualización de la app existente** (mismo Bundle ID, los usuarios la reciben como update y se conservan descargas y reseñas) — es lo que se acordó el 31/10. Para eso, en App Store Connect se sube este build sobre el registro existente de la app.
2. **Activar Duelos:** hoy está oculta. Cuando quieras encenderla, cambia `showDuels` a `true` en `Config.swift`.
3. **Funciones que necesitan backend (no incluidas en esta versión):** conteo de votos/duelos en tiempo real, «me gusta» de canciones, avisos push y panel de Samuel. La app está preparada para conectarlos después; por ahora Duelos vota en local (demostración) y Dedicatorias llega por WhatsApp.
4. **Capturas para la ficha de la tienda:** tomarlas del simulador o iPhone cuando la app corra (las pantallas son las del diseño aprobado).

## Archivos principales

| Archivo | Qué es |
|---|---|
| `NosanRadio/NosanRadioApp.swift` | Punto de entrada |
| `NosanRadio/Config.swift` | **Todos los ajustes**: stream, WhatsApp, colores, flag `showDuels` |
| `NosanRadio/AudioPlayer.swift` | Reproductor Live365 (fondo, interrupciones, lock screen) |
| `NosanRadio/ContentView.swift` | Barra de pestañas |
| `NosanRadio/Views/*.swift` | Las 5 pantallas |
| `NosanRadio/Info.plist` | Nombre visible "Nosan Radio", modo audio en fondo, launch screen |
| `NosanRadio/Assets.xcassets/` | Íconos de app + logo |

Diseño fuente: `workspace/nosan-radio/app-prototype/prototipo-v1.html` y especificación en `workspace/goals/nosan-radio-branding-and-viral-growth/files/especificacion-app-nueva.md`.
