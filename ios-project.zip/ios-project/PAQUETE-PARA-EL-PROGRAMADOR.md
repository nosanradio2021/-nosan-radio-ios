# Paquete para el programador — App Nosan Radio 98.4 (iOS)

*Preparado el 1/11/2026 por el equipo de Samuel. Entrégale esta carpeta completa (`ios-project/`) y esta hoja.*

## Qué es
Proyecto Xcode **completo y listo para compilar** de la app nativa de Nosan Radio 98.4.
- SwiftUI · iOS 16 o superior · Bundle ID `com.nosanradio.lamasromantica`
- 5 pantallas: **Inicio** (reproductor con el diseño aprobado), **Duelos**, **Dedicatorias**, **Donar**, **Contacto**
- La pestaña **Duelos está construida pero OCULTA** (`Config.showDuels = false`) — así la quiere el dueño por ahora; no activarla sin su orden.
- Stream en vivo de Live365, audio en segundo plano, botón de WhatsApp a la línea de oyentes **+1 832 277 4419**, todo el texto en español.

## Verificado el 1/11/2026
- Los 12 archivos fuente están presentes y coinciden con el proyecto (nada roto, nada suelto).
- Versión **2.0** — sale como **ACTUALIZACIÓN de la app que ya existe en la App Store** (la 1.0.1), conservando descargas y reseñas. No crear un registro nuevo.
- Íconos de app completos (incluido el de 1024) y pantalla de arranque con el logo.
- El campo de firma (`DEVELOPMENT_TEAM`) viene vacío a propósito: se llena en la Mac con la cuenta del dueño.

## Lo que hace el programador (en su Mac con Xcode 15+)
1. Copiar la carpeta a su Mac y abrir `NosanRadio.xcodeproj`.
2. En **Signing & Capabilities**, activar *Automatically manage signing* y elegir el **Team de Nosan Radio LLC** (el dueño inicia sesión con su Apple ID; el código de verificación le llega a su iPhone).
3. Correr la app en el simulador o en un iPhone y comprobar que compila sin errores.
4. **Product → Archive** → **Distribute App → App Store Connect → Upload**.
5. Avisar cuando el build aparezca en TestFlight. Hasta ahí llega su parte.

## Lo que NO toca sin orden del dueño
- El flag `showDuels` (Duelos queda oculta).
- El Bundle ID, los textos en español, los colores y el logo.
- No publicar ni enviar nada a revisión de Apple: de la tienda se encarga el equipo del dueño.

## Pendiente (no es trabajo del programador)
- El botón de **Donar** apunta a un enlace provisional de GoFundMe; el enlace real de la campaña 2026 se pone antes de publicar.
- Las capturas para la ficha de la tienda se toman del simulador cuando la app corra.
- Los keywords nuevos de la tienda ya están listos.

## Cómo se sabe que quedó bien
1. Compila sin errores en Xcode.
2. Al darle play, el stream suena y **sigue sonando con la pantalla apagada**.
3. El botón de dedicatorias abre WhatsApp al +1 832 277 4419 con el mensaje ya escrito.
4. La pestaña Duelos **no** aparece en la barra inferior.
